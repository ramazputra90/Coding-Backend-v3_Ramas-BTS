package com.spring.example.utill;

import com.spring.example.dto.SearchCriteria;
import com.spring.example.model.Checklist;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;

import java.util.ArrayList;
import java.util.List;

public class ChecklistSpecificationsBuilder {
    private final List<SearchCriteria> params;

    public ChecklistSpecificationsBuilder() {
        params = new ArrayList<>();
    }

    public ChecklistSpecificationsBuilder with(String key, String operation, Object value) {
        params.add(new SearchCriteria(key, operation, value));
        return this;
    }

    public Specification<Checklist> build() {
        if (params.size() == 0) {
            return null;
        }

        List<Specification<Checklist>> specs = new ArrayList<Specification<Checklist>>();
        for (SearchCriteria param : params) {
            specs.add(new ChecklistSpecification(param));
        }

        Specification<Checklist> result = specs.get(0);
        for (int i = 1; i < specs.size(); i++) {
            result = Specifications.where(result).and(specs.get(i));
        }
        return result;
    }
}
