package com.spring.example.repository;

import com.spring.example.model.Checklist;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ChecklistRepository extends PagingAndSortingRepository<Checklist, Long>, JpaSpecificationExecutor<Checklist> {
    Checklist findById(Long id);
}
