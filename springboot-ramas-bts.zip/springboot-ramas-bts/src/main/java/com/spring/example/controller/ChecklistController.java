package com.spring.example.controller;

import com.spring.example.utill.ChecklistSpecificationsBuilder;
import com.spring.example.model.Checklist;
import com.spring.example.service.ChecklistService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@RestController
@RequestMapping("/api")
public class ChecklistController {

    @Autowired
    ChecklistService checklistService;

    //-------------------create checklist -------------------
    @PostMapping("/checklist")
    ResponseEntity<?> createChecklist(@RequestBody Checklist request) {
        Checklist response = checklistService.createChecklist(request);
        return new ResponseEntity<Object>(response, HttpStatus.OK);
    }

    //-------read the checklist in json format with pagination----------
    @RequestMapping(value = "/stories", method = RequestMethod.GET, produces = {"application/json"})
    ResponseEntity<?> getAllChecklist(@RequestParam(value = "page", defaultValue = "0") int page,
                                  @RequestParam(value = "limit", defaultValue = "5") int limit) {
        Page<Checklist> response = checklistService.getAllChecklist(page, limit);
        return new ResponseEntity<Object>(response, HttpStatus.OK);
    }

    //--------------------update the checklist --------------------
    @RequestMapping(value = "/checklist/{id}", method = RequestMethod.PUT, consumes = {"application/json"}, produces = {"application/json"})
    public ResponseEntity<?> updateChecklist(@PathVariable(value = "id") Long checklistId, @RequestBody Checklist checklistDetails) {
        Checklist response = checklistService.updateChecklist(checklistId, checklistDetails);
        return new ResponseEntity<Object>(response, HttpStatus.OK);
    }

    //---------------------delete the checklist ---------------------
    @DeleteMapping("/checklist/{id}")
    public ResponseEntity<?> deleteChecklist(@PathVariable(value = "id") Long checklistId) {
        checklistService.deleteChecklist(checklistId);
        return ResponseEntity.ok().build();
    }

    //------------------------search  checklist ------------------------
    @RequestMapping(method = RequestMethod.GET, value = "/checklist")
    public ResponseEntity<?> search(@RequestParam(value = "search") String search) {
        ChecklistSpecificationsBuilder builder = new ChecklistSpecificationsBuilder();
        Pattern pattern = Pattern.compile("(\\w+?)(:|<|>)(\\w+?),");
        Matcher matcher = pattern.matcher(search + ",");
        while (matcher.find()) {
            builder.with(matcher.group(1), matcher.group(2), matcher.group(3));
        }
        Specification<Checklist> spec = builder.build();
        List<Checklist> response = checklistService.searchChecklist(spec);
        return new ResponseEntity<Object>(response, HttpStatus.OK);
    }
}
